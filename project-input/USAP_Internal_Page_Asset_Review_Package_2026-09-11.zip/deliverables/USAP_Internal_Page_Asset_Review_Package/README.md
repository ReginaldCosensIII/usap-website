# USAP Internal-Page Asset Review Package

Prepared for visual review and USAP technical approval.

## Purpose

This package groups the About Us, Contact Us, Request a Quote, and Technical Resources image assets developed during the current exploration. Website headings, body copy, buttons, logos, overlays, and responsive behavior are intentionally not flattened into the individual images.

The three revised **About Us — Manufacturing & Testing** candidates are grounded in current USAP product pages and official USAP data sheets. They supersede the earlier generic workshop/rotator/RF-test explorations, which are not included here.

## Accuracy classification

- **Reference-grounded visualization:** Generated artwork whose subject, materials, interfaces, and proportions are based on an official USAP photograph and/or published USAP specifications. It is not documentary photography, a manufacturing drawing, or a dimensional acceptance record.
- **Conceptual communication illustration:** A generic service/process visual that does not claim to depict a particular USAP product, employee, facility, customer, or installation.

AI-generated pixels cannot certify a dimension or component fit. Any asset depicting recognizable product hardware should receive USAP engineering/product-owner approval before publication.

## About Us

### `about-us/usap-about-hero-lp1017-clean-v2.png`

- Intended use: approved About Us desktop hero direction.
- Size: 2048 × 768 pixels; opaque sRGB PNG.
- Subject: LP-1017-family log-periodic system visualization.
- Treatment: right-weighted product composition with open space for HTML copy and a later navy CSS overlay.
- Classification: reference-grounded visualization.

### `about-us/usap-about-integrated-support-lp1112mr-clean-v2.png`

- Intended use: approved About Us Integrated Support section image.
- Size: 1536 × 1024 pixels; opaque sRGB PNG.
- Subject: LP-1112MR-family transportable HF antenna-system visualization.
- Classification: reference-grounded visualization.

## About Us — Manufacturing & Testing replacement candidates

### Candidate A — Structural inspection

File: `about-us/manufacturing-testing/usap-about-manufacturing-structural-inspection-aperiodic-loop-candidate-a-v2.png`

- Size: 1536 × 1024 pixels; opaque sRGB PNG.
- Intended message: aluminum assembly, welded joints, supports, and structural review without depicting a fictional USAP factory.
- Grounding: current USAP Aperiodic Loop Antenna data sheet and its transportable-version photograph.
- Preserved subject cues: two circular loop elements, central vertical support, lower feed/preamplifier area, and low curved transportable support.
- Published facts used: the loop element is a welded aluminum-alloy assembly weighing 10 lb; a preamplifier is fitted at the antenna base; tripod and post-mounted versions are described.
- Accuracy limitation: USAP does not publish the loop diameter, tube diameter, loop spacing, tripod footprint, or fastener specification in the referenced sheet. The image preserves photographed proportions but must not be treated as an exact dimensional record.
- Classification: reference-grounded visualization.

### Candidate B — Rotation mechanism

File: `about-us/manufacturing-testing/usap-about-manufacturing-rotation-mechanism-r3500-candidate-b-v2.png`

- Size: 1536 × 1024 pixels; opaque sRGB PNG.
- Intended message: heavy-duty mechanical engineering, enclosed drive, mounting, and long-service construction.
- Grounding: current USAP Model R3500 data sheet and official product photograph.
- Preserved subject cues: low gray protective housing, circular output/mast opening and bolt circle, connecting gearcase, horizontal TEFC motor, mounting feet, and restrained power/control lead.
- Published facts used to guide scale and construction: 18 in W × 23 in L × 7 in H; 85 lb; worm-gear drive; 1/4 HP TEFC 48 VDC motor; 2–3 in mast-shaft acceptance; up to 1-5/8 in concentric transmission-line passage.
- Accuracy limitation: the image is a geometry- and proportion-guided visualization, not a CAD model. Exact casting profiles, hole locations, hardware counts, tolerances, and finish should be confirmed by USAP before publication.
- Classification: reference-grounded visualization.

### Candidate C — RF testing

File: `about-us/manufacturing-testing/usap-about-manufacturing-rf-interface-lp1019-candidate-c-v2.png`

- Size: 1536 × 1024 pixels; opaque sRGB PNG.
- Intended message: RF connection, feed-interface inspection, and test discipline without repeating a full antenna hero.
- Grounding: current USAP LP-1019/LP-1019SS data sheet and official LP-1019 photograph.
- Preserved/documented cues: extruded aluminum structure, stainless-steel hardware, fiberglass detail, Type-N female input, and one RG-213/U test lead for the balanced-array version.
- Published facts used: LP-1019BA boom 55 in; longest element 59 in tip-to-tip; aluminum and stainless-steel hardware; Type-N female input; RG-213/U recommended for runs of 50 ft or less.
- Accuracy limitation: the public photography does not provide a production-close-up of every feed-block surface, clamp, and fastener. The connector/material combination is documented, but the generated local housing geometry requires USAP review. No test result is shown or implied.
- Classification: reference-grounded visualization.

### `about-us/manufacturing-testing/usap-about-manufacturing-candidates-comparison-v2.png`

- Intended use: review-only comparison sheet. It contains labels; do not use it as website artwork.

## Contact Us hero candidates

All three files are 2048 × 768 opaque sRGB PNGs designed for the shared internal-page hero with a navy CSS overlay and HTML content on the left.

- `contact-us/usap-contact-hero-support-headset-candidate-a-v1.png` — support-headset service illustration; conceptual communication illustration.
- `contact-us/usap-contact-hero-telephone-receiver-candidate-b-v1.png` — telephone/contact illustration; conceptual communication illustration. Recommended primary Contact Us candidate.
- `contact-us/usap-contact-hero-communication-signal-candidate-c-v1.png` — abstract communication/signal illustration; conceptual communication illustration. Confirm at page-preview size that the waveform cannot be misread as medical monitoring.

## Request a Quote hero candidates

Both files are 2048 × 768 opaque sRGB PNGs designed for the shared internal-page hero with a navy CSS overlay and HTML content on the left.

- `request-a-quote/usap-quote-hero-technical-planning-candidate-a-v1.png` — technical planning and scope-definition concept. Recommended primary Request a Quote candidate.
- `request-a-quote/usap-quote-hero-custom-engineering-candidate-c-v1.png` — custom engineering/configuration concept. Alternate quote-page direction.

These are conceptual service illustrations and do not depict a USAP employee, customer, facility, contract, product specification, or completed quote.

## Technical Resources hero candidate

### `technical-resources/usap-technical-resources-hero-requirements-document-candidate-b-v1.png`

- Size: 2048 × 768 pixels; opaque sRGB PNG.
- Intended use: Technical Resources or technical-documents hero.
- Previous classification: originally explored as Request a Quote Candidate B.
- Current classification: reassigned to Technical Resources because its requirements/document visual language is a better content fit.
- Accuracy classification: conceptual communication illustration; document content is non-readable and does not claim to reproduce a USAP manual or specification.

## Official USAP source register

- About USAP: https://www.usantennaproducts.com/about-usap/
- LP-1017 product page: https://www.usantennaproducts.com/antennas/model-lp-1017/
- LP-1017 data sheet: https://www.usantennaproducts.com/wp-content/uploads/2016/05/1017-data-sheet-4.pdf
- LP-1112MR product page: https://www.usantennaproducts.com/antennas/model-lp-1112mr/
- Aperiodic Loop Antenna product page: https://www.usantennaproducts.com/antennas/usap-aperiodic-loop-antenna/
- Aperiodic Loop Antenna data sheet: https://www.usantennaproducts.com/wp-content/uploads/2016/06/USAP-Aperiodic-Loop-Antenna-data-sheet.pdf
- R3500 product page: https://www.usantennaproducts.com/antennas/model-r3500/
- R3500 data sheet: https://www.usantennaproducts.com/wp-content/uploads/2016/07/MODEL-R3500-data-sheet.doc.pdf
- LP-1019/LP-1019SS product page: https://www.usantennaproducts.com/antennas/models-lp-1019-lp-1019ss/
- LP-1019/LP-1019SS data sheet: https://www.usantennaproducts.com/wp-content/uploads/2016/06/1019-and-1019-ss-data-sheet.pdf

## Website-use guidance

- Keep all text, buttons, logos, and accessibility content in HTML/CSS.
- Apply the final brand-navy overlay in CSS; avoid permanently crushing image detail.
- Test hero crops at desktop, tablet, and mobile breakpoints before producing derivatives.
- Do not identify a generated scene as a real USAP facility, employee, customer installation, or test result.
- Do not use the comparison sheet in production.
- Do not infer unpublished dimensions or specifications from generated pixels.
- Retain this README with the approval record so reviewers can distinguish published facts from visual interpretation.

## Excluded/superseded work

The earlier generic Structural Inspection, generic exposed-gear Rotation Mechanism, generic RF Testing, and full LP-1019 Manufacturing & Testing concepts are intentionally excluded from this approval package. They were useful explorations but do not meet the final evidence threshold or page-variety goal.

## Approval checklist

Before production use, ask USAP to confirm:

1. The recognizable geometry of each reference-grounded product family.
2. The acceptability of the visible materials, fastener patterns, feed assembly, and motor/housing relationships.
3. That no image could be mistaken for a documentary photo of a real facility, installation, or measured test.
4. The selected image crop and CSS overlay at every responsive breakpoint.

